import 'dart:ui';

class MyTheme {
  static Color blue = Color(0xFF42A5F5);
  static Color red = Color(0xfff54d63);
}
