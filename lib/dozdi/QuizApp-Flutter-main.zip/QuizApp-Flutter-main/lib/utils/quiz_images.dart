const url="https://github.com/muhammad-fiaz/QuizApp-Flutter/assets/75434191/06e28a7a-6239-4a3f-af88-4a49b272ce9e";

const quiziccommunication = url;
const quiziccommunication2 = url;
const quiziccourse1 = url;
const quiziccourse2 = url;
const quiziccourse3 = url;
const quizicinfo = url;
const quizicjava = url;
const quizicmarketing = url;
const quizicnotification = url;
const quizicstudy1 = url;
const quizicstudy2 = url;
const quizicquiz1 = "images/quiz/quiz_ic_quiz1.png";
const quizicquiz2 = "images/quiz/quiz_ic_quiz2.png";
const quizicquiz = "images/quiz/quiz_ic_quiz.svg";
const quizichomes = "images/quiz/quiz_ic_home.svg";
const quizicuser = "images/quiz/quiz_ic_user.svg";
const quizicfacebook = "images/quiz/quiz_ic_facebook.svg";
const quizicgoogle = "images/quiz/quiz_ic_google.svg";
const quizicmail = "images/quiz/quiz_ic_mail.svg";
const quizictwitter = "images/quiz/quiz_ic_twitter.svg";

const quizicGrid = "images/quiz/quiz_ic_grid.png";
const quizicList = "images/quiz/quiz_ic_list.png";
const quizimgPeople1 = url;
const quizimgPeople2 = url;

const quiziclist1 = "images/quiz/quiz_ic_list1.png";
const quiziclist2 = "images/quiz/quiz_ic_list2.png";
const quiziclist3 = "images/quiz/quiz_ic_list3.png";
const quiziclist4 = "images/quiz/quiz_ic_list4.png";
const quiziclist5 = "images/quiz/quiz_ic_list5.png";
