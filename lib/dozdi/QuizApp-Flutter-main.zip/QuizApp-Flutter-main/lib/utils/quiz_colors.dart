import 'package:flutter/material.dart';

const t8colorPrimary = Color(0xFF5362FB);
const t8colorPrimaryDark = Color(0xFF3D50FC);
const t8colorAccent = Color(0xFF22D8CD);

const t8colorred = Color(0xFFF12727);
const t8textColorPrimary = Color(0xFF333333);
const t8textColorSecondary = Color(0xFF918F8F);

const t8appbackground = Color(0xFFf3f5f9);
const t8viewcolor = Color(0xFFDADADA);

const t8white = Color(0xFFffffff);

const t8iconcolor = Color(0xFF747474);
const t8colorgreen = Color(0xFF8BC34A);
const t8editbackground = Color(0xFFF5F4F4);
const t8lightgray = Color(0xFFCECACA);
const t8colorsdots = Color(0xFF009688);

const t8green = Color(0xFF00FF00);
const t8red = Color(0xFFFF0000);
const t8colorsetting = Color(0xFFACB5FD);
const t8colormessage = Color(0xFF5362FB);
const t8colormail = Color(0xFF62D3AB);
const t8colorfacebook = Color(0xFF4872FB);
const t8colortwitter = Color(0xFF2CB6F8);
const t8colortransparent = Color(0xFF00FFFFFF);
const t8ShadowColor = Color(0X95E9EBF0);
const t8formgoogle = Color(0xFFF13B19);

const quizcolorPrimary = Color(0xFF5362FB);
const quizcolorPrimaryDark = Color(0xFF3D50FC);
const quizcolorAccent = Color(0xFF22D8CD);

const quizcolorred = Color(0xFFF12727);
const quiztextColorPrimary = Color(0xFF333333);
const quiztextColorSecondary = Color(0xFF918F8F);

const quizappbackground = Color(0xFFf3f5f9);
const quizviewcolor = Color(0xFFDADADA);

const quizwhite = Color(0xFFffffff);

const quiziconcolor = Color(0xFF747474);
const quizcolorgreen = Color(0xFF8BC34A);
const quizeditbackground = Color(0xFFF5F4F4);
const quizlightgray = Color(0xFFCECACA);
const quizcolorsdots = Color(0xFF009688);

const quizgreen = Color(0xFF00FF00);
const quizred = Color(0xFFFF0000);
const quizcolorsetting = Color(0xFFACB5FD);
const quizcolormessage = Color(0xFF5362FB);
const quizcolormail = Color(0xFF62D3AB);
const quizcolorfacebook = Color(0xFF4872FB);
const quizcolortwitter = Color(0xFF2CB6F8);
const quizcolortransparent = Color(0xFF00FFFFFF);
const quizShadowColor = Color(0X95E9EBF0);
const quizformgoogle = Color(0xFFF13B19);
