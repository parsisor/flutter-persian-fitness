package dev.muhammadfiaz.quiz.quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
